document.getElementById('collect').addEventListener('click', async () => {
  await collectAndDisplayData('text'); // 默认收集文本格式
});

document.getElementById('markdown').addEventListener('click', async () => {
  await collectAndDownloadMarkdown(); // 下载 Markdown 文件
});

async function collectAndDisplayData(format) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const collectButton = document.getElementById('collect');
  const markdownButton = document.getElementById('markdown');
  const recordCountDisplay = document.getElementById('record-count');

  try {
    collectButton.disabled = true;
    markdownButton.disabled = true;
    collectButton.textContent = '收集中...';
    markdownButton.textContent = '下载中...'; // 修改文字为 "下载中..."

    const response = await chrome.tabs.sendMessage(tab.id, { action: 'collect' });
    if (format === 'markdown') {
      //  不再显示在 text area
    } else {
      //  不再显示在 text area
    }
    recordCountDisplay.textContent = `共找到 ${response.count} 条上榜记录`;

  } catch (error) {
    recordCountDisplay.textContent = '出错了: 请确保在正确的网页上使用此插件';
  } finally {
    collectButton.disabled = false;
    markdownButton.disabled = false;
    collectButton.textContent = '收集数据';
    markdownButton.textContent = '下载Markdown'; // 恢复文字为 "下载Markdown"
  }
}

async function collectAndDownloadMarkdown() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const collectButton = document.getElementById('collect');
  const markdownButton = document.getElementById('markdown');
  const recordCountDisplay = document.getElementById('record-count');
  const status = document.getElementById('status');

  try {
    collectButton.disabled = true;
    markdownButton.disabled = true;
    collectButton.textContent = '收集中...';
    markdownButton.textContent = '下载中...';

    const response = await chrome.tabs.sendMessage(tab.id, { action: 'collect' });
    const markdownData = response.markdown;
    const filename = `hot-search-data-${new Date().toISOString()}.md`; // 使用日期时间生成文件名

    // 创建下载链接
    const blob = new Blob([markdownData], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = filename; // 指定文件名
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(url); // 释放 URL

    // 显示下载成功提示
    status.classList.remove('hidden');
    setTimeout(() => {
      status.classList.add('hidden');
    }, 2000);

  } catch (error) {
    recordCountDisplay.textContent = '出错了: 请确保在正确的网页上使用此插件';
  } finally {
    collectButton.disabled = false;
    markdownButton.disabled = false;
    collectButton.textContent = '收集数据';
    markdownButton.textContent = '下载Markdown';
  }
}