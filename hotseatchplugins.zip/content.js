// 收集页面数据并转换为简单文本格式
function collectTextData() {
  const items = document.querySelectorAll('.search-list-item');
  let text = '';

  items.forEach(item => {
    const title = item.querySelector('.name').textContent;
    const type = item.querySelector('.type').textContent;
    const date = item.querySelector('.date').textContent.replace('最近上榜:', '');
    const time = item.querySelector('.time').textContent.replace('累计在榜:', '');
    const rank = item.querySelector('.rank').textContent.replace('最高排名:', '');

    // 将所有内容拼接成一行
    text += `${title} ${type} ${date} ${time}最高排名:${rank}\n`;
  });

  return text;
}

// 收集页面数据并转换为 Markdown 格式
function collectMarkdownData() {
  const items = document.querySelectorAll('.search-list-item');
  let markdown = '';

  items.forEach(item => {
    const title = item.querySelector('.name').textContent;
    const type = item.querySelector('.type').textContent;
    const date = item.querySelector('.date').textContent;
    const time = item.querySelector('.time').textContent;
    const rankText = item.querySelector('.rank').textContent;
    const rank = rankText.replace('最高排名:', '').trim();

    markdown += `${title} ${type} ${date} ${time} 最高排名:${rank}\n`;
  });

  return markdown;
}

// 收集数据并返回文本和记录数
function collectData() {
    const items = document.querySelectorAll('.search-list-item');
    const textData = collectTextData();
    const markdownData = collectMarkdownData();
    const recordCount = items.length;
    return { text: textData, count: recordCount, markdown: markdownData };
}

// 监听来自 popup 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'collect') {
    const data = collectData();
    sendResponse({ text: data.text, count: data.count, markdown: data.markdown });
  }
});